## EGSnrc documentation

The EGSnrc user manuals in PDF format can be downloaded from the
[releases](https://github.com/nrc-cnrc/EGSnrc/releases) page. Download
the `EGSnrc-manuals.zip` archive, and unzip it. If you installed EGSnrc,
you may want to move the extraced PDF files to the `EGSnrc/HEN_HOUSE/doc`
directory for convenience.

The `src` folder contains the LaTeX source code for all the manuals, but you
might not be able to compile them on your computer if you don't have LaTeX or
all the required LaTeX packages.
