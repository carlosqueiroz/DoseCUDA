## EGSnrc documentation graphic files

All files in this directory and in the `grace` subdirectory are part of EGSnrc.

Some data files require strict formatting to work properly within EGSnrc, hence
it is not possible to insert a licence notice inside those files. They
are nevertheless distributed under the same terms as EGSnrc, and as a reminder a
copy of the LICENCE is included in this directory.
