## EGSnrc gui image collection

The following images were taken from the KDE project. Copyright is with the KDE project.
These images are distributed under the terms of the GNU General Public License, version 2,
a copy of which is included in this directory for reference.

 Image file                 |
:---------------------------|
 file-manager.png           |
 contents.png               |
 launch.png                 |
 make_kdevelop.png          |
 wizard-32.png              |
 configure.png              |


The following images were created by Ghada Hamdan.who was contracted by the National Research
Council of Canada. Copyright for these images is with the National Research Council of Canada.
They are distributed under the terms of the GNU Affero General Public License version 3, a
copy of which is included in this directory for reference.

 Image file                 |
:---------------------------|
 desktop_icon.jpg           |
 rocket_egg_tr_f1_300.jpeg  |
 rocket_egg_tr_f1.png       |

